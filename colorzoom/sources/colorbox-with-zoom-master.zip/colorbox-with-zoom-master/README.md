# colorbox-with-zoom
Sample Project Colorbox improvement with Zoom (using grab)
based on Colorbox and Jquery Zoom by Jack Moore
