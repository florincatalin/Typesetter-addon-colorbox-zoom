/*
#########################################################
jQuery plugin 'myLilBox'
Author: J. Krausz
Date: 2016-12-11
Version 1.0
#########################################################
*/
;(function($){
  $.fn.extend({
    myLilBox : function(options) {
      this.defaultOptions = {
        width : '60%',
        height : '60%'
      };
      var settings = $.extend({}, this.defaultOptions, options);
      var $this = $(this);
      if( $this.attr("href") ){
        var theLilBox = $('<div class="myLilBox" style="'
          +   'width:' + settings.width + '; '
          +   'height:' + settings.height + '; '
          +   'background-image:url(\'' + $this.attr("href") + '\');"'
          + '></div>');
        $("body").append(theLilBox);
        $(document).one("click", function(){
          $(".myLilBox").remove();
        });
      }else if( window.console ){
        console.log('myLilBox: ', $this, ' has no href attribute!');
      }
    }
  });
})(jQuery);