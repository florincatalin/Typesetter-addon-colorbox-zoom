<?php
/*
#########################################################
PHP class for Typesetter CMS - 'Replace Colorbox' plugin
Author: J. Krausz
Date: 2016-12-11
Version 1.0
#########################################################
*/

defined('is_running') or die('Not an entry point...');

class ReplaceColorbox{

  public static function GetHead(){
    global $page, $addonRelativeCode;
    $page->css_user[] = $addonRelativeCode . '/thirdparty/myLilBox/myLilBox.css';
    $page->head_js[] =  $addonRelativeCode . '/thirdparty/myLilBox/myLilBox.js';
    $page->jQueryCode .=  "\n" . 
    '$gp.links.gallery = function(evt, sel){
      evt.preventDefault();
      $(".myLilBox").remove();
      $(this).myLilBox({
        width : "90%",
        height : "90%"
      });
    };' 
    . "\n";
  }

}